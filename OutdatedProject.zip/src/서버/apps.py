from django.apps import AppConfig


class 서버Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = '서버'
